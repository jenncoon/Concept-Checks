# Accounting Concept Checks

Interactive accounting concept checks for 11 chapters.

SCORM 1.2 packages for LMS upload are available on request through this form: https://docs.google.com/forms/d/e/1FAIpQLSfLCQaaugCz-PNjrP8bhuuCvLqbJ_T8rrg2Wev-OtQg2PyVhg/viewform

- `index.html`: landing page linking to every game
- `instructor_guide.html`: how to upload SCORM packages (Canvas, Blackboard, Moodle, D2L) and use reflection cards
- `games/`: the playable single-file HTML games
- `LICENSE.txt`: copyright and permitted use

## Publish with GitHub Pages
1. Upload these files and folders to a repository, keeping the structure.
2. In the repository, go to Settings, then Pages.
3. Under Build and deployment, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
4. Your site will be at `https://<username>.github.io/<repository>/`.

## Copyright and use
(c) 2026 Jennifer Coon. All rights reserved. Free to use with students for non-commercial educational purposes. Redistribution or sale requires written permission. Contact: jcoonconsulting@gmail.com
